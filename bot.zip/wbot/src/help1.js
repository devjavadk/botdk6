const help1 = (prefix) => {

	return `
╔══✪〘 INFO 〙✪══
║
╠➥ 𝐃𝐄𝐕 𝐉𝐀𝐕𝐀
╠➥ *3.0*
╠➥ 𝐃𝐎𝐍𝐎:  ⃬⃗𝐃𝐄𝐕 𝐉𝐀𝐕𝐀⃖  ☔
╠➥ *wa.me/5511946817667*
╠➥ 𝐒𝐓𝐀𝐓𝐔𝐒: ON
║
╠══✪〘 MENU1 〙✪══
║
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
║
╠══✪〘 *FIM* 〙✪══

════════════════════
*𝐃𝐄𝐕 𝐉𝐀𝐕𝐀 YT* 🤗
*Digite ${prefix}dono para mais info*
════════════════════`
}
exports.help1 = help1


const help = (prefix) => {
	return `
╔══✪〘 INFO 〙✪══
║
╠➥ 𝐃𝐄𝐕 𝐉𝐀𝐕𝐀
╠➥ *3.0*
╠➥ 𝐃𝐎𝐍𝐎:  ⃬⃗𝐃𝐄𝐕 𝐉𝐀𝐕𝐀  ☔
╠➥ *wa.me/5511946817667*
╠➥ 𝐒𝐓𝐀𝐓𝐔𝐒: ON
║
╠══✪〘 MENU 〙✪══
║
╠➥ *${prefix}sticker*
╠➥ *${prefix}toimg*
╠➥ *${prefix}meme*
╠➥ *${prefix}memeindo*
╠➥ *${prefix}gtts*
╠➥ *${prefix}loli*
╠➥ *${prefix}nsfwloli*
╠➥ *${prefix}url2img*
╠➥ *${prefix}ocr*
╠➥ *${prefix}wait*
╠➥ *${prefix}setprefix*
║
╠══✪〘 OUTROS 〙✪══
║
╠➥ *${prefix}linkgroup*
╠➥ *${prefix}simih [1/0]*
╠➥ *${prefix}marcar*
╠➥ *${prefix}add [@]*
╠➥ *${prefix}kick [@]*
╠➥ *${prefix}promote [@]*
╠➥ *${prefix}demote*
╠➥ *${prefix}listadmins*
╠➥ *${prefix}tagall2*
╠➥ *${prefix}info*
╠➥ *${prefix}tagall3*
╠➥ *${prefix}blocklist*
╠➥ *${prefix}block [@]*
╠➥ *${prefix}unblock [@]*
╠➥ *${prefix}clearall*
╠➥ *${prefix}bc [ *texto* ]*
╠➥ *${prefix}welcome [1/0]*
╠➥ *${prefix}clone [@]*
╠➥ *${prefix}darkmenu*
╠➥ *${prefix}dono*
║
╠══✪〘 BASE 〙✪══
║
╠➥ 𝐃𝐄𝐕 𝐉𝐀𝐕𝐀
╠➥ Espero que tenham gostado seus cornos filha da mãe vai se inscrever no meu canal❤️
║https://youtube.com/channel/UCE7x81dLhF0BQSDLSqCUjBQ
╚═〘 𝐃𝐄𝐕 𝐉𝐀𝐕𝐀 〙`
}

exports.help = help






